function Account(id, name) {
	Object.defineProperty(this, "id", {
		configurable : false,
		get: function() {
			return id;
		},
		set : function (i) {
			id = i;
		}
		
	});
	this.customerName = name;
	
}
Account.prototype.getId = function() {
		return this.id;
};
	
Account.prototype.setId = function(newId) {
		this.id = newId;
};
	
Account.prototype.getCustomerName = function() {
		return this.customerName;
};
	
Account.prototype.setCustomerName = function(name) {
		this.customerName = name;
};

Account.prototype.getType = function() {
	return "NONE";
}


function SavingsAccount(id, name, pan) {
	Account.call(this,id,name);
	this.pan = pan;
}

SavingsAccount.prototype = Object.create(Account.prototype);
SavingsAccount.prototype.constructor = SavingsAccount;

SavingsAccount.prototype.getType = function() {
	return "SAVINGS";
}
