function getMonth(monthIndex) {
	var days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
	var names = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
	
	return (function() {
		var month = {
			name : names[monthIndex],
			days : days[monthIndex]
		};
		return month;
	});
}

var jan = getMonth(0);
console.log(jan().name);
console.log(jan().days);

var feb = getMonth(1);
console.log(feb().name);
console.log(feb().days);