function AccountService() {
	function getAccounts() {
		var accounts = new Array(); //[]
		var sa1 = new SavingsAccount(1,"Arun","AH6543D");
		var sa2 = new SavingsAccount(2,"Ram","XDS6543D");
		accounts.push(sa1);
		accounts.push(sa2);
		
		console.log(JSON.stringify(accounts));
		
		return accounts;
	}
	
	window.accountService = {
		get : getAccounts
	};
}