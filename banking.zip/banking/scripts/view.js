function AccountsView(service, container) {
	this.service = service;
	this.container = container;
}
AccountsView.prototype.buildView = function() {
	var containerElement = document.getElementById(this.container);
	
	//create table
	var tableElement = document.createElement("table");
	containerElement.appendChild(tableElement);
	
	//create header
	var thead = tableElement.createTHead();
	var thr = thead.insertRow();
	
	var accounts = this.service.get();
	var sampleAccount = accounts[0];
	
	//add header columns for each attribute in object
	for(var colIndex in Object.getOwnPropertyNames(sampleAccount)) {
		var tdElement = document.createElement("td");
		tdElement.innerHTML = Object.getOwnPropertyNames(sampleAccount)[colIndex];
		thr.appendChild(tdElement);
	}
	
	//add content rows for each element in array
	for (var accountIndex in accounts) {
		var trElement = tableElement.insertRow();
		var account = accounts[accountIndex];
		for(var colIndex in Object.getOwnPropertyNames(sampleAccount)) {
			var tdElement = document.createElement("td");
			var attrName = Object.getOwnPropertyNames(sampleAccount)[colIndex];
			tdElement.innerHTML = account[attrName];
			trElement.appendChild(tdElement);
		}
	}
};