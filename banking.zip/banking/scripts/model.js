function Account() {
	var id;
	var customerName;
	
	this.getId = function() {
		return id;
	};
	
	this.setId = function(newId) {
		id = newId;
	};
	
	this.getCustomerName = function() {
		return customerName;
	};
	
	this.setCustomerName = function(name) {
		customerName = name;
	};
}

var account = new Account();
account.setId(123);

var account2 = new Account();
account2.setId(456);

console.log(account.getId());
console.log(account2.getId());
