package com.yodlee.rest.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Account {
	private Long id;
	private String customerName;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(Long id, String customerName) {
		super();
		this.id = id;
		this.customerName = customerName;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
}
