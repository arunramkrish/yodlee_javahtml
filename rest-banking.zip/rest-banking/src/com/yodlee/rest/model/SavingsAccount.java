package com.yodlee.rest.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SavingsAccount extends Account {
	private String pan;

	public SavingsAccount() {
		super();
	}


	public SavingsAccount(Long id, String customerName, String pan) {
		super(id, customerName);
		this.pan = pan;
	}


	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}
	
}
