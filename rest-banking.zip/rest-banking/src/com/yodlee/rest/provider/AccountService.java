package com.yodlee.rest.provider;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.server.mvc.Viewable;

import com.yodlee.rest.model.SavingsAccount;

@Path("/accounts")
public class AccountService {
	private static Long accountsCount = 1L;
	private static Map<Long, SavingsAccount> accounts = new HashMap<Long, SavingsAccount>();

	@POST
	@Consumes({ MediaType.APPLICATION_FORM_URLENCODED })
	@Produces({ MediaType.APPLICATION_JSON })
	public Response create(@FormParam("customerName") String customerName,
			@FormParam("pan") String pan) {
		SavingsAccount account = new SavingsAccount(accountsCount,
				customerName, pan);

		accounts.put(accountsCount, account);

		accountsCount++;

		Response response = Response.status(Response.Status.ACCEPTED)
				.entity(account).build();
		return response;
	}

	@POST
	@Consumes({ MediaType.APPLICATION_FORM_URLENCODED })
	@Produces({ MediaType.APPLICATION_XML })
	public SavingsAccount createOld(
			@FormParam("customerName") String customerName,
			@FormParam("pan") String pan) {
		SavingsAccount account = new SavingsAccount(accountsCount, customerName, pan);

		accounts.put(accountsCount, account);

		accountsCount++;

		return account;
	}

	// @GET
	// @Path("/{id}")
	// @Produces({ MediaType.APPLICATION_XML })
	// public Post get(@PathParam("id") long id) {
	// return posts.get(id);
	// }

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getAccounts() throws ServletException,
			IOException {
		
		Response response = Response.status(Response.Status.ACCEPTED)
				.entity(accounts).build();
		return response;
	}

	@GET
	@Path("/{id}")
	// @Produces({ MediaType.TEXT_HTML })
	public Viewable getAsHtml(@PathParam("id") long id,
			@Context HttpServletRequest request,
			@Context HttpServletResponse response) throws ServletException,
			IOException {
		request.setAttribute("account", accounts.get(id));

		return new Viewable("account.jsp");
	}

	@Path("/{id}")
	@PUT
	@Consumes({ MediaType.APPLICATION_FORM_URLENCODED })
	@Produces({ MediaType.APPLICATION_XML })
	public SavingsAccount update(@PathParam("id") Long id,
			@FormParam("customerName") String customerName, @FormParam("pan") String pan) {
		SavingsAccount account = accounts.get(id);
		account.setCustomerName(customerName);
		account.setPan(pan);

		return account;
	}

	@DELETE
	@Path("/{id}")
	@Produces({ MediaType.APPLICATION_XML })
	public SavingsAccount delete(@PathParam("id") long id) {
		SavingsAccount account = accounts.get(id);
		accounts.remove(id);

		return account;
	}

}
