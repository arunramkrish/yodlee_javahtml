function AccountService() {
	var accounts;

	function loadAccounts(callback) {
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = loadAccounts;
		xhr.open("GET", "api/accounts", true);
		xhr.send(null);

		function loadAccounts() {
			if (xhr.readyState == 4) {
				if (xhr.status == 200) {
					try {
						window.localStorage.setItem("accounts", xhr.responseText);
						accounts = JSON.parse(xhr.responseText);
						callback();
					} catch (e) {
						console.log(e);
					}
				}
			}
		}

	}

	function addAccounts(account, callback) {
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = addAccountStateChange;
		xhr.open("POST", "api/accounts", true);
		xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		xhr.send("accountNumber=" + account.id + "&customerName="
				+ account.customerName + "&pan=" + account.pan);

		function addAccountStateChange() {
			if (xhr.readyState == 4) {
				if (xhr.status == 200) {
					try {
						var account = JSON.parse(xhr.responseText);
						console.log(account);
						callback();
					} catch (e) {
						console.log(e);
					}
				}
			}
		}

	}

	function getAccounts() {
		// var accounts = new Array(); //[]
		// var sa1 = new SavingsAccount(1,"Arun","AH6543D");
		// var sa2 = new SavingsAccount(2,"Ram","XDS6543D");
		// accounts.push(sa1);
		// accounts.push(sa2);
		//		
		// console.log(JSON.stringify(accounts));

		return accounts;
	}

	window.accountService = {
		get : getAccounts,
		load : loadAccounts,
		add: addAccounts
	};
}