if (window.yodlee) {
} else {
	window.yodlee = (function() {
		return {};
	})();
}
yodlee.model = (function() {
	return {
		Account: 	function() {
			var id;
			var customerName;
			
			this.getId = function() {
				return id;
			};
			
			this.setId = function(newId) {
				id = newId;
			};
			
			this.getCustomerName = function() {
				return customerName;
			};
			
			this.setCustomerName = function(name) {
				customerName = name;
			};
		}
	};
})();

var account = new yodlee.model.Account();
account.setId(123);

var account2 = new yodlee.model.Account();
account2.setId(456);

console.log(account.getId());
console.log(account2.getId());
